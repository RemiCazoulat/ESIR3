#include <MotionPlanning/SixDofConfigurationGraph.h>

namespace MotionPlanning
{

}