#include <AI/Tasks/Task.h>
#include <AI/Tasks/Operators.h>

static void testTasks()
{
}