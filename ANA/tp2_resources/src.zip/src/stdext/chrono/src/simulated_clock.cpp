#pragma once

#include <stdext/chrono/simulated_clock.h>

namespace stdext
{
	namespace chrono
	{
		simulated_clock::time_point simulated_clock::m_time;
	}
}